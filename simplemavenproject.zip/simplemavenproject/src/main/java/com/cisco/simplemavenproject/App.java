package com.cisco.simplemavenproject;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "welcome to the world of jenkins!" );
        System.out.println( "helo from project" );
    }
}
